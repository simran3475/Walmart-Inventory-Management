import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, Calendar, Target } from 'lucide-react';
import { mockProducts, mockForecastData } from '../data/mockData';

const Forecast: React.FC = () => {
  const [selectedProduct, setSelectedProduct] = useState('1');
  
  const availableProducts = mockProducts.filter(product => 
    mockForecastData[product.id]
  );
  
  const currentProduct = availableProducts.find(p => p.id === selectedProduct);
  const forecastData = mockForecastData[selectedProduct] || [];

  const accuracy = 94.2;
  const trend = '+12%';

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Demand Forecasting</h1>
          <p className="text-gray-600 mt-2">AI-powered sales predictions to optimize inventory planning</p>
        </div>
      </motion.div>

      {/* Stats Cards */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-1 md:grid-cols-3 gap-6"
      >
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-green-100 rounded-lg">
              <Target className="h-5 w-5 text-green-600" />
            </div>
            <span className="text-sm font-medium text-green-600">{trend}</span>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">{accuracy}%</div>
          <div className="text-sm text-gray-600">Forecast Accuracy</div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-blue-100 rounded-lg">
              <TrendingUp className="h-5 w-5 text-blue-600" />
            </div>
            <span className="text-sm font-medium text-blue-600">+8%</span>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">7 Days</div>
          <div className="text-sm text-gray-600">Forecast Horizon</div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Calendar className="h-5 w-5 text-purple-600" />
            </div>
            <span className="text-sm font-medium text-purple-600">Daily</span>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">4x</div>
          <div className="text-sm text-gray-600">Update Frequency</div>
        </div>
      </motion.div>

      {/* Product Selection */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900">Product Forecast</h2>
          <div className="flex items-center space-x-4">
            <label htmlFor="product-select" className="text-sm font-medium text-gray-700">
              Select Product:
            </label>
            <select
              id="product-select"
              value={selectedProduct}
              onChange={(e) => setSelectedProduct(e.target.value)}
              className="px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {availableProducts.map(product => (
                <option key={product.id} value={product.id}>
                  {product.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {currentProduct && (
          <div className="mb-6 p-4 bg-gray-50 rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <div className="text-sm text-gray-600">Current Stock</div>
                <div className="text-lg font-semibold text-gray-900">{currentProduct.stock}</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Predicted Demand</div>
                <div className="text-lg font-semibold text-gray-900">{currentProduct.predictedDemand}</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Days Until Expiry</div>
                <div className="text-lg font-semibold text-gray-900">{currentProduct.daysUntilExpiry}</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Current Price</div>
                <div className="text-lg font-semibold text-gray-900">${currentProduct.currentPrice.toFixed(2)}</div>
              </div>
            </div>
          </div>
        )}

        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={forecastData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis 
                dataKey="date" 
                stroke="#6b7280"
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
              />
              <YAxis stroke="#6b7280" tick={{ fontSize: 12 }} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #e5e7eb', 
                  borderRadius: '8px',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                }}
                labelFormatter={(value) => new Date(value).toLocaleDateString()}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="actual" 
                stroke="#3b82f6" 
                strokeWidth={3}
                dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
                name="Actual Sales"
              />
              <Line 
                type="monotone" 
                dataKey="predicted" 
                stroke="#10b981" 
                strokeWidth={3}
                strokeDasharray="5 5"
                dot={{ fill: '#10b981', strokeWidth: 2, r: 4 }}
                name="Predicted Sales"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* Insights */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
      >
        <h2 className="text-xl font-semibold text-gray-900 mb-4">AI Insights</h2>
        <div className="space-y-4">
          <div className="flex items-start space-x-3 p-4 bg-blue-50 rounded-lg">
            <div className="p-1 bg-blue-100 rounded-full mt-1">
              <TrendingUp className="h-4 w-4 text-blue-600" />
            </div>
            <div>
              <div className="font-medium text-blue-900">Demand Spike Expected</div>
              <div className="text-sm text-blue-700 mt-1">
                {currentProduct?.name} shows a 15% increase in predicted demand over the next 3 days. Consider restocking soon.
              </div>
            </div>
          </div>
          
          <div className="flex items-start space-x-3 p-4 bg-green-50 rounded-lg">
            <div className="p-1 bg-green-100 rounded-full mt-1">
              <Target className="h-4 w-4 text-green-600" />
            </div>
            <div>
              <div className="font-medium text-green-900">Optimal Stock Level</div>
              <div className="text-sm text-green-700 mt-1">
                Current stock is within optimal range. No immediate action required for this product.
              </div>
            </div>
          </div>
          
          <div className="flex items-start space-x-3 p-4 bg-yellow-50 rounded-lg">
            <div className="p-1 bg-yellow-100 rounded-full mt-1">
              <Calendar className="h-4 w-4 text-yellow-600" />
            </div>
            <div>
              <div className="font-medium text-yellow-900">Seasonal Pattern Detected</div>
              <div className="text-sm text-yellow-700 mt-1">
                Historical data shows increased demand on weekends. Plan accordingly for better inventory management.
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Forecast;