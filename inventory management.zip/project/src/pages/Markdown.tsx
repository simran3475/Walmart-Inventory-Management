import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Tag, DollarSign, TrendingDown, Calculator } from 'lucide-react';
import { mockMarkdownProducts } from '../data/mockData';

const Markdown: React.FC = () => {
  const [discounts, setDiscounts] = useState<Record<string, number>>({});

  const updateDiscount = (productId: string, discount: number) => {
    setDiscounts(prev => ({ ...prev, [productId]: discount }));
  };

  const calculateImpact = (product: any, customDiscount?: number) => {
    const discount = customDiscount ?? discounts[product.id] ?? product.suggestedDiscount;
    const discountedPrice = product.currentPrice * (1 - discount / 100);
    const potentialRevenue = discountedPrice * 20; // Assuming 20 units sold
    const savings = product.potentialSavings * (discount / product.suggestedDiscount);
    
    return {
      discountedPrice,
      potentialRevenue,
      savings: savings || 0
    };
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Markdown Optimization</h1>
          <p className="text-gray-600 mt-2">Smart pricing strategies to maximize revenue recovery</p>
        </div>
      </motion.div>

      {/* Summary Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-1 md:grid-cols-4 gap-6"
      >
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-orange-100 rounded-lg">
              <Tag className="h-5 w-5 text-orange-600" />
            </div>
            <span className="text-sm font-medium text-orange-600">+5</span>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">{mockMarkdownProducts.length}</div>
          <div className="text-sm text-gray-600">Eligible Items</div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-green-100 rounded-lg">
              <DollarSign className="h-5 w-5 text-green-600" />
            </div>
            <span className="text-sm font-medium text-green-600">87%</span>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">
            ${mockMarkdownProducts.reduce((sum, p) => sum + p.potentialSavings, 0).toFixed(0)}
          </div>
          <div className="text-sm text-gray-600">Potential Savings</div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-blue-100 rounded-lg">
              <TrendingDown className="h-5 w-5 text-blue-600" />
            </div>
            <span className="text-sm font-medium text-blue-600">Avg</span>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">
            {Math.round(mockMarkdownProducts.reduce((sum, p) => sum + p.suggestedDiscount, 0) / mockMarkdownProducts.length)}%
          </div>
          <div className="text-sm text-gray-600">Avg Discount</div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Calculator className="h-5 w-5 text-purple-600" />
            </div>
            <span className="text-sm font-medium text-purple-600">ROI</span>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">2.3x</div>
          <div className="text-sm text-gray-600">Recovery Rate</div>
        </div>
      </motion.div>

      {/* Markdown Products */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="space-y-4"
      >
        <h2 className="text-xl font-semibold text-gray-900">Products Eligible for Markdown</h2>
        
        {mockMarkdownProducts.map((product, index) => {
          const currentDiscount = discounts[product.id] ?? product.suggestedDiscount;
          const impact = calculateImpact(product, currentDiscount);
          
          return (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + index * 0.1 }}
              className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">{product.name}</h3>
                    <span className="text-sm text-red-600 bg-red-50 px-2 py-1 rounded-full">
                      Expires: {new Date(product.expiryDate).toLocaleDateString()}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <div className="text-sm text-gray-600">Current Price</div>
                      <div className="text-lg font-semibold text-gray-900">${product.currentPrice.toFixed(2)}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-600">Discounted Price</div>
                      <div className="text-lg font-semibold text-green-600">${impact.discountedPrice.toFixed(2)}</div>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-sm font-medium text-gray-700">
                        Discount Percentage
                      </label>
                      <span className="text-sm text-blue-600">
                        Suggested: {product.suggestedDiscount}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="70"
                      value={currentDiscount}
                      onChange={(e) => updateDiscount(product.id, parseInt(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                    />
                    <div className="flex justify-between text-xs text-gray-500 mt-1">
                      <span>10%</span>
                      <span className="font-medium text-blue-600">{currentDiscount}%</span>
                      <span>70%</span>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-medium text-gray-900 mb-3">Impact Preview</h4>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">New Price:</span>
                      <span className="text-sm font-medium text-gray-900">${impact.discountedPrice.toFixed(2)}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Discount Amount:</span>
                      <span className="text-sm font-medium text-red-600">
                        -${(product.currentPrice - impact.discountedPrice).toFixed(2)}
                      </span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Potential Revenue (20 units):</span>
                      <span className="text-sm font-medium text-green-600">${impact.potentialRevenue.toFixed(2)}</span>
                    </div>
                    
                    <div className="flex justify-between border-t border-gray-200 pt-2">
                      <span className="text-sm font-medium text-gray-900">Estimated Savings:</span>
                      <span className="text-sm font-bold text-blue-600">${impact.savings.toFixed(2)}</span>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-gray-200">
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700 transition-colors"
                    >
                      Apply {currentDiscount}% Markdown
                    </motion.button>
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </motion.div>

      {/* Markdown Strategy Tips */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
      >
        <h2 className="text-xl font-semibold text-gray-900 mb-4">AI Markdown Strategy</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-blue-50 rounded-lg">
            <div className="font-medium text-blue-900 mb-2">Timing Optimization</div>
            <div className="text-sm text-blue-700">
              Apply markdowns 2-3 days before expiry for maximum effectiveness
            </div>
          </div>
          
          <div className="p-4 bg-green-50 rounded-lg">
            <div className="font-medium text-green-900 mb-2">Price Elasticity</div>
            <div className="text-sm text-green-700">
              25-40% discounts typically yield best volume increases for perishables
            </div>
          </div>
          
          <div className="p-4 bg-purple-50 rounded-lg">
            <div className="font-medium text-purple-900 mb-2">Customer Behavior</div>
            <div className="text-sm text-purple-700">
              Weekend shoppers are 35% more likely to purchase marked-down items
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Markdown;